// Patten_Matching_2.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#include "stdafx.h"
#include <string.h>
#include <stdlib.h>
#define MAX_SIZE 5000

int pattern_find(char *string, char *pat)
{
	int k, j, start = 0;
	int find_str = 0;
	char line[80] = { 0, };
	int lasts = strlen(string)-1;
	int lastp = strlen(pat)-1;
	for (k = 0; k <= lasts - lastp; k++) {
		for (j = 0; j <= lastp; j++)
			if (string[k+j] != pat[j]) break; 
		if ( j == lastp+1) {
			find_str = k;
			printf("%d ", k);
			for(int i = 0; i < 40; i++){
				line[i] = *(string + k + i);
			}printf("%s\n", line);
		}
	}
	return find_str; 
}

void fail(char *pat, int *failure)
{
	int n = strlen(pat);
	failure[0] = -1;
	for (int j=1; j < n; j++) {
		int i = failure[j-1]; 
		while ((i>=0) && (pat[i+1] != pat[j]))
			i = failure[i];
			if (pat[i+1] == pat[j]) failure[j] = i+1;
			else failure[j] = -1;
	}
}
void pmatch(char *string, char *pattern, int *failure)
{
	int i = 0, j = 0;
	char line[80] = { 0, };
	int length_str= strlen(string);
	int length_pat = strlen(pattern);
	while ( i < length_str ) {
		if (j == length_pat){
			printf("%d ", i);
			for (int k = 0; k < 40; k++)
				line[k] = *(string + k + i - j);
			printf("%s\n", line);
		}
		if (string[i] == pattern[j]) 
		{ i++; j++; }
		else {
			if (j == 0) i++;
			else j = failure[j-1]+1;
		}
	}
return;
}

int _tmain(int argc, _TCHAR* argv[])
{
	char fname[20];
	char pat[40];
	int *failure;
	char str[MAX_SIZE] = { 0, };
	FILE* fp = NULL;
	int t_f;

	printf("text�� ���� ���ϸ��� �Է��Ͻÿ� : ");
	scanf("%s", fname);

	fp = fopen(fname, "r");			//���� �̸� : sample1.txt
	if(!fp){
		printf("���� �̸��� �߸� �Ǿ����ϴ�.\n");
		exit(EXIT_FAILURE);
	}

	int i = 0;
	while(1){
		if(feof(fp))
			break;
		fread(&str[i++], 1, 1, fp);
	}

	printf("�˻��� �ܾ �Է��Ͻÿ� : ");
	scanf("%s", pat);

	failure = (int*)malloc(strlen(pat) * 4);
	fail(pat, failure);

	t_f = pattern_find(str, pat);
	if(t_f == 0)
		printf("ã������ ���ڿ��� �����ϴ�.\n");
	
	printf("\n\n\n");
	pmatch(str, pat, failure);

	fclose(fp);

	free(failure);
	return 0;
}

