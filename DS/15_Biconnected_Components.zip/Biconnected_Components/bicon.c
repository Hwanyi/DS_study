#include <stdio.h>
#include <stdlib.h>

#define MIN2(x, y) ( (x) < (y) ? (x) : (y))

struct node{
	int vertex;
	struct node* link;
};

struct node_stack {
	int x;
	int y;
};

typedef struct node node;
typedef node *nodePointer;
typedef struct node_stack node_stack;

node_stack stack[10];
int top = -1;

nodePointer adjLists[10];
int visited[10];
int dfn[10];
int low[10];
int visited_num = 0;

void add_List(int vertex1, int vertex2) {
	nodePointer cur = adjLists[vertex1];
	nodePointer input_node;

	cur->vertex = vertex1;
	input_node = (nodePointer)malloc(sizeof(node));
	input_node->vertex = vertex2;
	input_node->link = NULL;

	while (1) {
		if (cur->link == NULL) {
			cur->link = input_node;
			break;
		}
		cur = cur->link;
	}

	cur = adjLists[vertex2];
	cur->vertex = vertex2;

	input_node = (nodePointer)malloc(sizeof(node));
	input_node->vertex = vertex1;
	input_node->link = NULL;

	while (1) {
		if (cur->link == NULL) {
			cur->link = input_node;
			break;
		}
		cur = cur->link;
	}
	return;
}


void initialize_adj() {
	for (int i = 0; i < 10; i++) {
		adjLists[i] = (nodePointer)malloc(sizeof(node));
		adjLists[i]->vertex = -1;
		adjLists[i]->link = NULL;
	}
}

void initialize_dfn(){
	for(int i = 0; i < 10; i++){
		visited[i] = 0;
		dfn[i] = -1;
		low[i] = -1;
	}
}

void dfnlow(int me, int parent)
{
	nodePointer ptr;
	int child;
	dfn[me] = low[me] = visited_num++;
	for (ptr = adjLists[me]; ptr; ptr = ptr->link) {
		child = ptr->vertex;
		if (dfn[child] < 0) {
			dfnlow(child, me);
			low[me] = MIN2(low[me],low[child]);
		}
		else if (child != parent) 
			low[me] = MIN2(low[me],dfn[child]);
	}
}

void push(int me, int child) {
	top++;
	stack[top].x = me;
	stack[top].y = child;
}

void pop(int* x, int* y) {
	if (top == -1) {
		*x = -1;
		*y = -1;
		return;
	}
	*x = stack[top].x;
	*y = stack[top].y;

	top--;
}

void bicon(int me, int parent)
{
	nodePointer ptr;
	int child, x, y;
	dfn[me] = low[me] = visited_num++;
	for (ptr = adjLists[me]->link; ptr; ptr = ptr->link) {
		child = ptr->vertex;
		if (parent != child && dfn[child] < dfn[me]) {
			push(me, child); 
		}
		if (dfn[child] < 0) { 
			bicon(child, me);
			low[me] = MIN2(low[me], low[child]);
			if (low[child] >= dfn[me]) { 
				printf("New biconnected component: ");
				do { 
					pop(&x, &y);
					printf(" <%d,%d>", x, y);
				} while (!((x == me) && (y == child)));
				printf("\n");
			}
		}
		else if (child != parent)
			low[me] = MIN2(low[me], dfn[child]);
	}
}
int main(){
	int v1;
	int v2;
	
	initialize_adj();
	initialize_dfn();

	printf("<vertex1 vertex2>\n");

	while(1){
		scanf("%d %d", &v1, &v2);
		if(v1 == -1)
			break;
		add_List(v1, v2);
	}
	printf("\n");

	dfnlow(3, -1);

	printf("vertex dfn low\n");
	for (int i = 0; i < 10; i++)
		printf("%d      %d   %d\n", i, dfn[i], low[i]);

	initialize_dfn();
	visited_num = 0;
	bicon(3, -1);

	return 0;
}