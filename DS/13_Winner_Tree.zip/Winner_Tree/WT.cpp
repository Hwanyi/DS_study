#include <stdio.h>
#include "WT.h"

int w_tree[8];
int result[200];
int result_index = 0;
typedef struct element__ {
	int run[100];
	int index;
	int n_o_e;	//number of entry
}element;

element run_arr[8];

int main() {

	/*****************************************************/
	for (int i = 0; i < 8; i++)
	{
		run_arr[i].index = 0;
		run_arr[i].n_o_e = 0;
	}
	for (int i = 0; i < 101; i++)
	{
		if ((i / 8) % 2 == 0)
			run_arr[i % 8].run[run_arr[i % 8].n_o_e++] = i;
		else
			run_arr[7 - (i % 8)].run[run_arr[7 - (i % 8)].n_o_e++] = i;
	}
	
	for (int i = 0; i < 8; i++)
	{
		int index = 0;
		printf("run %d : ", i);
		while (1) {
			if (index == run_arr[i].n_o_e)
				break;
			printf("%d ", run_arr[i].run[index]);
			index++;
		}
		printf("\n");
	}
	/*****************************************************///run �ʱ�ȭ
	initialize_WT();
	/*****************************************************///Tree �ʱ�ȭ
	while (1) {
		if(w_tree[1] == -1)
			break;
		get_top();
		adjust_WT();
	}
	/****************************************************///WT
	for (int i = 0; i < result_index; i++)
	{
		printf("%d ", result[i]);
	}
	return 0;
}

void initialize_WT() {
	for (int i = 0; i < 4; i++)
		if (run_arr[i * 2].run[0] <= run_arr[i * 2 + 1].run[0])
			w_tree[i + 4] = i * 2;
		else
			w_tree[i + 4] = i * 2 + 1;
	
	if (run_arr[w_tree[4]].run[0] <= run_arr[w_tree[5]].run[0])
		w_tree[2] = w_tree[4];
	else
		w_tree[2] = w_tree[5];

	if (run_arr[w_tree[6]].run[0] <= run_arr[w_tree[7]].run[0])
		w_tree[3] = w_tree[6];
	else
		w_tree[3] = w_tree[7];

	if (run_arr[w_tree[2]].run[0] <= run_arr[w_tree[3]].run[0])
		w_tree[1] = w_tree[2];
	else
		w_tree[1] = w_tree[3];

	printf("An adjusted winner tree : ");
	for (int i = 1; i < 8; i++)
		printf("%d ", w_tree[i]);
	printf("\n\n");


	return;
}

void get_top() {
	result[result_index] = run_arr[w_tree[1]].run[run_arr[w_tree[1]].index];
	result_index++;

	if (run_arr[w_tree[1]].index == run_arr[w_tree[1]].n_o_e - 1 || run_arr[w_tree[1]].index == -1)
		run_arr[w_tree[1]].index = -1;
	else 
		run_arr[w_tree[1]].index++;

	return;
}

void adjust_WT() {
	int parent = (w_tree[1]/2) + 4;
	int left_c = (parent - 4) * 2;
	int right_c = (parent - 4) * 2 + 1;

	if (run_arr[left_c].index == -1 && run_arr[right_c].index == -1)
		w_tree[parent] = -1;
	else if (run_arr[left_c].index == -1)
		w_tree[parent] = right_c;
	else if (run_arr[right_c].index == -1)
		w_tree[parent] = left_c;
	else {
		if (run_arr[left_c].run[run_arr[left_c].index] <= run_arr[right_c].run[run_arr[right_c].index])
			w_tree[parent] = left_c;
		else
			w_tree[parent] = right_c;
	}

	parent /= 2;
	while (1) {
		if (parent == 0)
			break;
		int child_L = parent * 2;
		int child_R = parent * 2 + 1;

		if (w_tree[child_L] != -1 && w_tree[child_R] != -1) {
			if (run_arr[w_tree[child_L]].index == -1 && run_arr[w_tree[child_R]].index == -1)
				w_tree[parent] = -1;
			else if (run_arr[w_tree[child_L]].index == -1)
				w_tree[parent] = w_tree[child_R];
			else if (run_arr[w_tree[child_R]].index == -1)
				w_tree[parent] = w_tree[child_L];
			else {
				if (run_arr[w_tree[child_L]].run[run_arr[w_tree[child_L]].index] <= run_arr[w_tree[child_R]].run[run_arr[w_tree[child_R]].index])
					w_tree[parent] = w_tree[child_L];
				else
					w_tree[parent] = w_tree[child_R];
			}
		}
		else {
			if (w_tree[child_L] == -1 && w_tree[child_R] == -1)
				w_tree[parent] = -1;
			else if (w_tree[child_L] == -1)
				w_tree[parent] = w_tree[child_R];
			else
				w_tree[parent] = w_tree[child_L];
		}
		parent /= 2;
	}
	

	return;
}