#pragma once

void initialize_WT();
void get_top();
void adjust_WT();