#pragma once
typedef struct node node, *nodePointer;

typedef struct data data;

nodePointer make_node();
void insert();
nodePointer find_node(int num);
void find();
void read();
void push(nodePointer ptr);
nodePointer pop();
void read_child();
void node_delete();
void delete_all_node();