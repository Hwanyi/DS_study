#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "tree.h"

struct data {
	char name[40];
	char address[100];
	int id;
};

struct node {
	data employee;
	nodePointer leftnode;
	nodePointer rightnode;
};

nodePointer root = NULL;

nodePointer stack[100];	//����� ���� ����
int top = -1;

int main() {
	char c;


	while (1) {
		printf("i(����), d(����), f(Ž��), r(��ü �б�), c(�ڽĵ� �б�), q(�۾�����)�� �����Ͻÿ� : ");
		scanf("%c", &c);
		getchar();		//����Ű ����
		if (c =='q')
			break;
		switch (c) {
		case 'i':
			insert();
			break;
		case 'f':
			find();
			break;
		case 'd':
			node_delete();
			break;
		case 'c':
			read_child();
			break;
		case 'r':
			read();
			break;
		}

	}
	printf("���α׷��� �����մϴ�.\n");
	delete_all_node();
	return 0;
}

nodePointer make_node() {
	char line[200];
	char *p;
	nodePointer ptr = (nodePointer)malloc(sizeof(node));
	ptr->leftnode = NULL;
	ptr->rightnode = NULL;
	printf("������ �ڷ�(ID, �̸�, �ּ�)�� �Է��Ͻÿ�. : ");
	fgets(line, 200, stdin);
	p = strtok(line, " ");
	ptr->employee.id = atoi(p);
	p = strtok(NULL, " ");
	strcpy(ptr->employee.name, p);
	p = strtok(NULL, "\n");
	strcpy(ptr->employee.address, p);
	return ptr;
}

void insert() {
	nodePointer parents;
	nodePointer ptr = NULL;
	ptr = make_node();
	if (root == NULL) {
		root = ptr;
		return;
	}


	parents = root;
	while (1) {
		if (parents->employee.id > ptr->employee.id) {
			if (parents->leftnode == NULL) {
				parents->leftnode = ptr;
				break;
			}
			parents = parents->leftnode;
		}
		else {
			if (parents->rightnode == NULL) {
				parents->rightnode = ptr;
				break;
			}
			parents = parents->rightnode;
		}
	}
	return;
}

void find() {
	int num;
	nodePointer ptr;
	printf("Ž���� �ڷ��� ����� �Է��Ͻÿ� : ");
	scanf("%d", &num);
	getchar(); //����Ű ����

	ptr = find_node(num);
	if (ptr == NULL)
		printf("�ڷᰡ �����ϴ�.\n");
	else
		printf("<���, �̸�, �ּ�> : <%d , %s, %s>\n", ptr->employee.id, ptr->employee.name, ptr->employee.address);
	return;
}

nodePointer find_node(int num) {
	nodePointer ptr = root;
	while (1) {
		if (ptr == NULL)
			break;

		if (ptr->employee.id == num)
			break;

		if (ptr->employee.id > num)
			ptr = ptr->leftnode;
		else
			ptr = ptr->rightnode;
	}
	return ptr;
}

void read() {
	nodePointer ptr = root;
	printf("<���, �̸�, �ּ�>\n");
	while (1) {
		while (ptr != NULL) {
			push(ptr);
			ptr = ptr->leftnode;
		}
		ptr = pop();
		if (ptr == NULL)
			break;
		printf("<%d , %s, %s>\n", ptr->employee.id, ptr->employee.name, ptr->employee.address);
		ptr = ptr->rightnode;
	}
	return;
}

void push(nodePointer ptr) {
	top++;
	stack[top] = ptr;
	return;
}

nodePointer pop() {
	nodePointer ptr;
	if (top == -1)
		return NULL;

	ptr = stack[top];
	top--;
	return ptr;
}

void read_child() {
	nodePointer ptr;
	int num;
	printf("Ž���� �ڷ��� ����� �Է��ϼ���. : ");
	scanf("%d", &num);
	getchar();
	ptr = find_node(num);
	if (ptr == NULL) {
		printf("�ڷᰡ �����ϴ�.\n");
		return;
	}
	printf("<%d, %s, %s>\n", ptr->employee.id, ptr->employee.name, ptr->employee.address);
	printf("����  �ڽ� : ");
	if (ptr->leftnode == NULL)
		printf("����\n");
	else
		printf("<%d , %s, %s>\n", ptr->leftnode->employee.id, ptr->leftnode->employee.name, ptr->leftnode->employee.address);

	printf("������  �ڽ� : ");
	if (ptr->rightnode == NULL)
		printf("����\n");
	else
		printf("<%d , %s, %s>\n", ptr->rightnode->employee.id, ptr->rightnode->employee.name, ptr->rightnode->employee.address);
	return;
}

void node_delete() {
	int num;
	nodePointer ptr = root;
	nodePointer p_parents = NULL;
	nodePointer small;
	nodePointer s_parents;
	printf("������ �ڷ��� ����� �Է��ϼ���. : ");
	scanf("%d", &num);
	getchar();

	while (1) {
		if (ptr == NULL)
			break;

		if (ptr->employee.id == num)
			break;

		if (ptr->employee.id > num) {
			p_parents = ptr;
			ptr = ptr->leftnode;
		}
		else{
			p_parents = ptr;
			ptr = ptr->rightnode; 
		}
	}

	if (ptr == NULL) {
		printf("ã������ �ڷᰡ �����ϴ�.\n");
		return;
	}

	if (ptr->rightnode == NULL && ptr->leftnode == NULL) {
		if (ptr->employee.id > p_parents->employee.id)
			p_parents->rightnode = NULL;
		else
			p_parents->leftnode = NULL;
	}
	else if (ptr->rightnode == NULL && ptr->leftnode != NULL) {
		if (ptr->employee.id > p_parents->employee.id)
			p_parents->rightnode = ptr->leftnode;
		else
			p_parents->leftnode = ptr->leftnode;
	}
	else if (ptr->rightnode != NULL && ptr->leftnode == NULL) {
		if (ptr->employee.id > p_parents->employee.id)
			p_parents->rightnode = ptr->rightnode;
		else
			p_parents->leftnode = ptr->rightnode;
	}
	else {
		s_parents = ptr;
		small = ptr->rightnode;
		while (1) {
			if (small->leftnode == NULL)
				break;
			s_parents = small;
			small = small->leftnode;
		}
		if (s_parents == ptr) {
			s_parents->rightnode = small->rightnode;
		}
		else {
			s_parents->leftnode = small->rightnode;
		}

		ptr->employee = small->employee;
		ptr = small;
	}
	free(ptr);
	return;
}

void delete_all_node() {
	nodePointer ptr = root;
	nodePointer f_node;
	while (1) {
		while (ptr != NULL) {
			push(ptr);
			ptr = ptr->leftnode;
		}
		ptr = pop();
		if (ptr == NULL)
			break;
		f_node = ptr;
		ptr = ptr->rightnode;
		free(f_node);
	}
	return;
}