#pragma once

typedef struct {
	int id;
	char name[20];
	char address[100];
}data;

typedef struct node {
	data employee;
	struct node * next;
}node_, *list;

void insert_list();
void delete_list();
list find_list(int id);
void read_list();
void add_list(list node);
void delete_all();