#pragma once

#define MAX_SIZE 100

typedef struct {
	int id;
	char name[20];
	char address[100];
}data;

typedef struct node {
	data employee;
	int next;
	int prev;
}node;

void Insert_list();
void point_next();
void read_list();
void find_list();
void delete_list();