#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_NUM 100000

inline void swap(int *x, int *y) {
	int z = *x;
	*x = *y;
	*y = z;
}

void merge(int a[], int b[], int left_s, int left_e, int right_e) {
	int left, right, target;
	left = left_s;
	right = left_e + 1;
	target = left;
	while (1) {
		if (left == left_e + 1 || right == right_e + 1)
			break;
		if (a[left] > a[right])
			b[target++] = a[right++];
		else
			b[target++] = a[left++];
	}

	if (left == left_e + 1) {
		while (1) {
			if (right == right_e + 1)
				break;
			b[target++] = a[right++];
		}		
	}
	else {
		while (1) {
			if (left == left_e + 1)
				break;
			b[target++] = a[left++];
		}
	}
}

void merge_pass(int a[], int b[], int end_index, int run_size) {
	int left, target;
	left = 1;

	while (1) {
		if (left > (end_index - 2 * run_size + 1))
			break;
		merge(a, b, left, left+run_size - 1, left + 2*run_size - 1);
		left += 2 * run_size;
	}

	if (left + run_size - 1 < end_index)
		merge(a, b, left, left + run_size - 1, end_index);
	else {
		for (target = left; target <= end_index; target++)
			b[target] = a[target];
	}
}

void merge_sort(int a[], int n) {
	int run_size = 1;
	int extra[MAX_NUM];

	while (run_size < MAX_NUM) {
		merge_pass(a, extra, MAX_NUM - 1, run_size);
		run_size *= 2;
		merge_pass(extra, a, MAX_NUM - 1, run_size);
		run_size *= 2;
	}
}

void adjust(int a[], int root, int n) {
	int child, root_key;
	int temp;
	temp = a[root];
	child = 2* root;
	root_key = a[root];
	while (1) {
		if (child > n)
			break;
		if ((child < n) && (a[child] < a[child + 1]))
			child++;
		if (root_key > a[child])
			break;
		else {
			a[child / 2] = a[child];
			child *= 2;
		}
	}
	a[child / 2] = temp;
}

void heap_sort(int a[], int n) {
	for (int i = n/2; i > 0; i--)
	{
		adjust(a, i, n);
	}

	for (int i = n - 1; i > 0; i--)
	{
		swap(&a[1], &a[i + 1]);
		adjust(a, 1, i);
	}
}

void selection_sort(int a[], int n) {
	int min;
	for (int i = 0; i < n - 1; i++)
	{
		min = i;
		for (int j = i; j < n; j++)
		{
			if (a[min] > a[j])
				min = j;
		}
		if (min != i) {
			swap(&a[min], &a[i]);
		}
	}
	return;
}

void insertion_sort(int a[], int n) {
	int j;
	int temp;
	for (int i = 1; i < n; i++)
	{
		j = i;
		temp = a[i];
		while (1) {
			if (temp > a[j - 1])
				break;
			a[j] = a[j - 1];
			j--;
			if (j == 0)
				break;
		}
		a[j] = temp;

	}
	return;
}

void quick_sort_median(int a[], int left, int right) {
	int pivot, i, j;
	int median;
	if (left < right) {
		i = left; j = right + 1; median = (left + right) / 2;
		if (a[median] < a[right]) {
			if (a[left] < a[median])
				swap(a + left, a + median);
			else if (a[right] < a[left])
				swap(a + left, a + right);
		}
		pivot = a[left];
		do {
			do { i++; } while (a[i] < pivot);
			do { j--; } while (pivot < a[j]);
			if (i < j) swap(&a[i], &a[j]);
		} while (i < j);
		swap(&a[left], &a[j]);
		quick_sort_median(a, left, j - 1);
		quick_sort_median(a, j + 1, right);
	}
}

int main() {
	int orig_arr[MAX_NUM];
	clock_t start_t;
	clock_t end_t;

	for (int i = 0; i < MAX_NUM; i++)
		orig_arr[i] = rand();
	
	printf("start!\n");

	start_t = clock();
	
	//selection_sort(orig_arr, MAX_NUM);
	//insertion_sort(orig_arr, MAX_NUM);
	//quick_sort_median(orig_arr, 0, MAX_NUM - 1);
	//merge_sort(orig_arr, MAX_NUM);
	heap_sort(orig_arr, MAX_NUM - 1);


	end_t = clock();

	printf("number : %d\ntime : %d\n", MAX_NUM, end_t - start_t);
/*
	for (int i = 0; i < MAX_NUM; i++)
	{
		printf("%d ", orig_arr[i]);
	}
	*///Ȯ�ο�

	return 0;
}