// Maze.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#include "stdafx.h"
#define MAX_STACK_SIZE 100
#define _CTR_SECURE_NO_WARNINGS_

offsets move[8] = {-1, 0,	//N
					-1, 1,	//NE
					0, 1,	//E
					1, 1,	//SE
					1, 0,	//S
					1, -1,	//SW
					0, -1,	//W
					-1, -1	//NW
};
element stack[MAX_STACK_SIZE];
int top = -1;

int _tmain(int argc, _TCHAR* argv[])
{
	FILE* rf = fopen("maze2.txt", "r+");
	char** maze;
	char** visited;
	int ROW = 0;
	int COL = 0;
	char line[80];
	fgets(line, 80, rf);
	COL = strlen(line) - 1;
	while(1){
		if(feof(rf))
			break;
		ROW++;
		fgets(line, 80, rf);
	}
	rewind(rf);
	maze = (char**)malloc(sizeof(char*) * (ROW + 2));
	visited = (char**)malloc(sizeof(char*) * (ROW + 2));
	for (int i = 0; i < ROW + 2; i++){
		maze[i] = (char*)malloc(sizeof(char) * (COL + 2));
		visited[i] = (char*)malloc(sizeof(char) * (COL + 2));
	}
	
	for(int i = 0; i < ROW + 2; i++){
		for(int j = 0; j < COL + 2; j++){
			maze[i][j] = '1';
		}
	}

	fgets(line, 80, rf);
	for(int i = 1; i < ROW + 1; i++){
		if(feof(rf))
			break;
		for(int j = 1; j < COL + 1; j++){
			maze[i][j] = line[j - 1];
		}
		fgets(line, 80, rf);
	}

	fclose(rf);

	for(int i = 0; i < ROW + 2; i++){
		for(int j = 0; j < COL + 2; j++){
			visited[i][j] = '0';
		}
	}
	
	printf("maze\n");
	for(int i = 1; i < ROW + 1; i++){
		for(int j = 1; j < COL + 1; j++){
			printf("%2c", maze[i][j]);
		}
		printf("\n");
	}

	int found = 0;
	element position = {1, 1, 1};
	visited[1][1] = '1';
	push(position);
	int row, col, dir, exit_row = ROW, exit_col = COL, nextRow, nextCol;
	while(1){
		if(top == -1 || found != 0)
			break;
		position = pop();
		row = position.row;
		col = position.col;
		dir = position.dir;
		while(1){
			if(found != 0 || dir == 8)
				break;
			nextRow = row + move[dir].vert;
			nextCol = col + move[dir].horiz;
			if(nextRow == exit_row && nextCol == exit_col)
				found = 1;
			else if(maze[nextRow][nextCol] == '0' && visited[nextRow][nextCol] == '0'){
				visited[nextRow][nextCol] = 1;
				position.row = row; position.col = col; position.dir = ++dir;
				push(position);
				row = nextRow; col = nextCol; dir = 0;
			}
			else
				dir++;
		}
	}
	if(found == 1){
		printf("The path is :\n");
		printf("row col\n");
		for (int i = 0; i <= top; i++)
			printf("%2d%5d\n", stack[i].row, stack[i].col);
		printf("%2d%5d\n", row, col);
		printf("%2d%5d\n", exit_row, exit_col);
	}else
		printf("The maze does not have a path\n");

	for(int i = 0; i < ROW + 2; i++){
		free(maze[i]);
		free(visited[i]);
	}
	free(maze);
	free(visited);
	return 0;
}

void push(element position){
	if(top + 1 == MAX_STACK_SIZE){
		printf("Stack is Full!\n");
		exit(1);
	}
	top++;
	stack[top].col = position.col;
	stack[top].row = position.row;
	stack[top].dir = position.dir;
}

element pop(){
	if(top < 0){
		printf("Stack is empty!\n");
		exit(1);
	}
	element position;
	position.col = stack[top].col;
	position.row = stack[top].row;
	position.dir = stack[top].dir;
	top--;
	return position;
}