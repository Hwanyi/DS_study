typedef struct {
	short int vert; // x
	short int horiz; // y
} offsets;

typedef struct{
	short row;
	short col;
	int dir;
}element;


element pop();

void push(element stack);