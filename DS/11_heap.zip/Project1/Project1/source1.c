#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "heap.h"

#define Max_size 100

struct data {
	int id;
	char name[40];
	char address[100];
};


data heap[Max_size] = { 0, };
int current = 0;

int main() {
	char c;

	while (1) {
		printf("i(����), d(����), r(��ü �б�), q(�۾�����)�� �����Ͻÿ� : ");
		scanf("%c", &c);
		getchar();			//���๮�� ����
		switch (c)
		{
		case 'i':
			insert_data();
			break;
		case 'd':
			delete_data();
			break;
		case 'r':
			read_data();
			break;
		case 'q':
			return 0;
		default:
			break;
		}
	}

	return 1;
}


void insert_data() {
	char line[200];
	char* p;
	data item;
	int cur;
	current++;

	if (current >= Max_size) {
		fprintf(stderr, "Heap is full!\n");
		exit(EXIT_FAILURE);
	}

	printf("������ �ڷ�(ID, �̸�, �ּ�)�� �Է��Ͻÿ�. : ");
	fgets(line, 200, stdin);
	p = strtok(line, " ");
	item.id = atoi(p);
	p = strtok(NULL, " ");
	strcpy(item.name, p);
	p = strtok(NULL, "\n");
	strcpy(item.address, p);


	cur = current;
	while (1) {
		if (cur == 1)
			break;
		if (heap[cur/2].id >= item.id)
			break;
		heap[cur] = heap[cur / 2];
		cur /= 2;
	}
	heap[cur] = item;
	return;
}

void delete_data() {
	data item;
	int cur = 1;
	if (current == 0) {
		fprintf(stderr, "Heap is empty!\n");
		exit(EXIT_FAILURE);
	}
	item = heap[1];
	printf("<�й� �̸� �ּ�> = <%d %s %s>\n", item.id, item.name, item.address);
	item = heap[current];
	heap[current].id = 0;
	current--;

	while (1) {
		if (cur * 2 > current) 
			break;
		if (heap[cur * 2].id > heap[cur * 2 + 1].id) {
			if (heap[cur * 2].id > item.id) {
				heap[cur] = heap[cur * 2];
				cur *= 2;
			}
			else break;
		}
		else {
			if (heap[cur * 2 + 1].id > item.id) {
				heap[cur] = heap[cur * 2 + 1];
				cur = cur * 2 + 1;
			}
			else break;
		}
	}
	heap[cur] = item;
	return;
}

void read_data() {

	printf("<�й�, �̸�, �ּ�>\n");
	for (int i = 1; i <= current; i++)
		printf("<%d, %s, %s>\n", heap[i].id, heap[i].name, heap[i].address);

}
