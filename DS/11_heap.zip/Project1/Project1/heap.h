#pragma once

typedef struct data data;

void flush_stdin();
void insert_data();
void delete_data();
void read_data();