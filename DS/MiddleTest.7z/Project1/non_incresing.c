#include <stdio.h>

void selection_sort(int a[], int size);

int main() {
	int i;
	int list[10] = { 0, 1, 2, 39, 4, 51, 6, 79, 8, 9 };
	int size = sizeof(list)/sizeof(int);

	selection_sort(list, size);

	printf("\n Sorted array :\n");
	for (i = 0; i < 10; i++)
		printf("%d ", list[i]);
	printf("\n");

	return 0;
}

void selection_sort(int a[], int size) {
	int x;
	int y;
	int max;
	int temp;

	for (x = 0; x < size - 1; x++) {
		max = a[x];
		temp = x;
		for (y = x; y <= size - 1; y++) {
			if (max < a[y]) {
				max = a[y];
				temp = y;
			}
		}
		if (temp != x) {
			a[temp] = a[x];
			a[x] = max;
		}
	}

	return;
}