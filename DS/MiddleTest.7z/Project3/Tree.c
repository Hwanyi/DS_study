#include <stdio.h>
#include <string.h>

typedef struct Employee {
	char name[20];
	int age;
	struct Employee *left_c;
	struct Employee *right_c;
}emp;

void add_Q(emp* ptr);
emp* delete_Q();
void level_Order();
void Search_T(char name[]);

emp *root = NULL;
emp arr[8];
emp* Queue[8];

int front;
int rear;

int main() {
	char name_1[20];
	char name_2[20];
	root = arr;

	printf("8���� ������ �Է��ϼ���\n�̸� ����\n");
	for (int i = 0; i < 8; i++)
	{
		arr[i].left_c = arr[i].right_c = NULL; //Child �ʱ�ȭ
		scanf("%s %d", arr[i].name, &arr[i].age);
		getchar();	//����Ű ����
	}
	printf("\n");

	int relative;
	int i;
	int x, y;
	while (1) {
		printf("�θ�_������ ���� �ڽ�_������ : ");
		scanf("%s %d %s", name_1, &relative, name_2);
		getchar(); //���ͱ� ����
		if (!strcmp(name_1, "NULL"))
			break;

		for (i = 0; i < 8; i++)
		{
			if (!strcmp(name_1, arr[i].name))
				x = i;
			if (!strcmp(name_2, arr[i].name))
				y = i;
		}
		if (relative == 0)
			arr[x].left_c = &arr[y];
		else if (relative == 1)
			arr[x].right_c = &arr[y];
		if (&arr[y] == root)
			root = &arr[x];
	}

	printf("\nLevel Order ��� :\n");
	level_Order();
	
	while (1) {
		char name[20];
		printf("���̸� �˰� ���� ���� �̸� : ");
		scanf("%s", name);
		getchar(); //���� ����
		if (!strcmp(name, "NULL"))
			break;
		Search_T(name);
	}

	return 0;
}

void add_Q(emp* ptr) {
	if (front == rear + 1)
		return 1;
	Queue[rear] = ptr;
	rear++;
	return ;
}

emp* delete_Q() {
	emp* ptr;
	if (front == rear)
		return NULL;
	ptr = Queue[front];
	front++;
	return ptr;
}

void level_Order() {
	int i = 1;
	int level_up = 1;
	int level = 1;
	front = 0;
	rear = 0;
	emp* ptr = root;

	add_Q(ptr);

	while (1) {
		ptr = delete_Q();
		if (ptr == NULL)
			break;
		if (i == level_up) {
			printf("\nLevel %d : ", level++);
		}


		printf("<%s, %d>[", ptr->name, ptr->age);
		if (ptr->left_c != NULL) {
			add_Q(ptr->left_c);
			printf("%s, ", ptr->left_c->name);
			level_up += 2;
			i++;
		}
		else {
			printf("NULL, ");
			i++;

		}
		if (ptr->right_c != NULL) {
			add_Q(ptr->right_c);
			printf("%s", ptr->right_c->name);
			level_up += 2;
			i++;
		}
		else {
			printf("NULL");
			i++;
			i++;
		}
		printf("] ");
	}
	printf("\n");
	

	return;
}

void Search_T(char name[]) {
	int i;
	int j = 0;
	int same_age = 0;
	int up_age = 0;
	int down_age = 0;
	emp* stack[8];

	for (i = 0; i < 8; i++)
		if (!strcmp(arr[i].name, name))
			break;
	
	if (i == 8)
		return;

	emp* ptr = &arr[i];
	front = 0;
	rear = 0;

	add_Q(ptr);
	j++;

	
	while (1) {
		ptr = delete_Q();
		if (ptr == NULL)
			break;

		if (ptr->left_c != NULL) {
			add_Q(ptr->left_c);
			j++;
		}

		if (ptr->right_c != NULL) {
			add_Q(ptr->right_c);
			j++;
		}
	}

	for (int k = 1; k < j; k++)
	{
		if (arr[i].age > Queue[k]->age)
			down_age++;
		else if (arr[i].age == Queue[k]->age)
			same_age++;
		else
			up_age++;
	}

	printf("%s�� ���� : %d\n", arr[i].name, arr[i].age);
	printf("%s�� �ļյ� �� %s���� ���̰� ���� ���� �� : %d\n", arr[i].name, arr[i].name, up_age);
	printf("%s�� �ļյ� �� %s�� ���̰� ���� ���� �� : %d\n", arr[i].name, arr[i].name, same_age);
	printf("%s�� �ļյ� �� %s���� ���̰� ���� ���� �� : %d\n", arr[i].name, arr[i].name, down_age);

	return;
}