#include <stdio.h>
#include <stdlib.h>
#define MAX_NUM 100000

typedef struct node {
	int head_node;
	int cost;
	struct node* next;
}node;

typedef struct adj_list {
	int parents;
	int distance;
	struct node* next;
}adj_list;

adj_list list[10];
int fixed[10];
int total_vertax;

void initialize_list() {
	for (int i = 0; i < 10; i++)
	{
		list[i].distance = MAX_NUM;
		list[i].parents = -1;
		list[i].next = NULL;
		fixed[i] = 0;
	}
}

void Create_node(int tail, int head, int cost) {
	node* cur = list[tail].next;
	node* new_node = (node*)malloc(sizeof(node));
	new_node->head_node = head;
	new_node->cost = cost;
	new_node->next = NULL;

	if (cur == NULL) {
		list[tail].next = new_node;
		return;
	}

	new_node->next = cur->next;
	cur->next = new_node;

	return;
}

int choose_min_distance_vertex()
{
	int x, min, minpos;
	min = MAX_NUM;
	minpos = -1;
	for (x = 0; x < total_vertax; x++) {
		if (!fixed[x] && list[x].distance < min) {
			min = list[x].distance; minpos = x;
		}
	}
	return minpos;
}

int find_cost(int tail, int head) {
	node* cur = list[tail].next;
	int cost;
	while (1) { // cost ã��
		if (cur == NULL) {
			cost = MAX_NUM;
			break;
		}

		if (cur->head_node == head) {
			cost = cur->cost;
			break;
		}

		cur = cur->next;
	}

	return cost;
}

int update_found_distance_parent(int new_vertex) {
	int new_distance;
	int cost;

	for (int i = 0; i < total_vertax; i++)
	{
		if (fixed[i] == 0) {
			cost = find_cost(new_vertex , i);
			if (cost == MAX_NUM)
				continue;

			new_distance = list[new_vertex].distance + cost;


			if (new_distance < list[i].distance) {
				list[i].distance = new_distance;
				list[i].parents = new_vertex;
			}
		}
	}

	return;
}

void shortestPath(int start_vertex)
{
	int x, new_vertex;

	if (start_vertex < 0) return;

	list[start_vertex].distance = 0;

	for (x = 0; x < total_vertax - 1; x++) {
		new_vertex = choose_min_distance_vertex();
		if (new_vertex < 0) break;
		fixed[new_vertex] = 1;
		update_found_distance_parent(new_vertex);
	}
	return;
}


//list version
int main() {
	int head_node;
	int tail_node;
	int edge_cost;

	initialize_list();


	printf("vertax ������ �Է��ϼ��� : ");
	scanf("%d", &total_vertax);

	printf("Tail_node Head_node Cost ������ �Է��ϼ���.(-1 -1 -1: exit)\n");
	while (1) {	
		scanf("%d %d %d", &tail_node, &head_node, &edge_cost);
		if (tail_node == -1)
			break;
		Create_node(tail_node, head_node, edge_cost);
	}

	printf("-----------------------\n");
	
	/*for (int i = 0; i < total_vertax; i++)
	{
		node* cur = list[i].next;
		printf("%d : ", i);
		while (1) {
			if (cur == NULL)
				break;
			printf("%d ", cur->head_node);
			cur = cur->next;
		}
		printf("\n");
	}
*///adjacency_list Ȯ�ο�

	shortestPath(0);		//ex1
	//shortestPath(4);		//ex2

	printf("parents ");
	for (int i = 0; i < total_vertax; i++)
		printf("%d ", list[i].parents);
	printf("\n");

	printf("childs ");
	for (int i = 0; i < total_vertax; i++)
		printf("%d ", i);
	printf("\n");

	printf("distance ");
	for (int i = 0; i < total_vertax; i++)
		printf("%d ", list[i].distance);
	printf("\n");

	for (int i = 0; i < total_vertax; i++)
	{
		if (list[i].parents == -1)
			continue;
		printf("length = %d		", list[i].distance);
		printf("path : ");
		int cur_v = i;
		while (1) {
			if (cur_v == -1)
				break;
			printf("%d ", cur_v);
			cur_v = list[cur_v].parents;
		}
		printf("\n");
	}

	return 0;
}