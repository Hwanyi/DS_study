#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "tree.h"

nodePointer stack[100];
int top = -1;

struct data {
	char name[40];
	char address[100];
};

struct node {
	int num;
	data employee;
	nodePointer leftnode;
	nodePointer rightnode;
};

nodePointer root = NULL;

int main() {
	char a;
	
	while (1) {
		fflush(stdin);
		printf("i(����), d(����), f(Ž��), r(��ü �б�), c(�ڽĵ� �б�), q(�۾�����)�� �����Ͻÿ� : ");
		scanf("%c", &a);
		getchar(); //����Ű ����
		if (a == 'q')
			break;
		switch (a)
		{
		case 'i':
			insert();
			break;
		case 'd':
			
			break;
		case 'f':
			find();
			break;
		case 'r':
			read();
			break;
		case 'c':
			read_child();
			break;
		default:
			break;
		}
	}
	return 0;
}

void insert() {
	char line[200];
	char* p;
	nodePointer parents = root;
	nodePointer ptr = (nodePointer)malloc(sizeof(node));
	ptr->leftnode = NULL;
	ptr->rightnode = NULL;
	fflush(stdin);
	printf("������ �ڷ�(ID, �̸�, �ּ�)�� �Է��Ͻÿ�. : ");
	fgets(line, 200, stdin);
	p = strtok(line, " ");
	ptr->num = atoi(p);
	p = strtok(NULL, " ");
	strcpy(ptr->employee.name, p);
	p = strtok(NULL, "\n");
	strcpy(ptr->employee.address, p);
	
	if (root == NULL) {
		root = ptr;
		return;
	}
	while (1) {
		if (parents->num > ptr->num) {
			if (parents->leftnode == NULL) {
				parents->leftnode = ptr;
				break;
			}
			parents = parents->leftnode;
		}
		else {
			if (parents->rightnode == NULL) {
				parents->rightnode = ptr;
				break;
			}
			parents = parents->rightnode;
		}
	}
	return;
}

nodePointer find() {
	int n;
	int found = 0;
	nodePointer ptr = root;
	printf("Ž���� �ڷ��� ����� �Է��Ͻÿ� : ");
	scanf("%d", &n);
	getchar(); //����Ű ����
	while (1) {
		if (ptr == NULL)
			break;

		if (ptr->num == n) {
			found = 1;
			break;
		}

		if (ptr->num > n) 
			ptr = ptr->leftnode;
		else 
			ptr = ptr->rightnode;	
	}
	if (found == 0)
		printf("�ڷᰡ �����ϴ�.\n");
	else
		printf("<���, �̸�, �ּ�> : <%d , %s, %s>\n", n, ptr->employee.name, ptr->employee.address);
	return ptr;
}

void read() {
	nodePointer ptr = root;
	printf("<���, �̸�, �ּ�>\n");
	while (1) {
		while (ptr != NULL) {
			push(ptr);
			ptr = ptr->leftnode;
		}
		ptr = pop();
		if (ptr == NULL)
			break;
		printf("<%d , %s, %s>\n", ptr->num, ptr->employee.name, ptr->employee.address);
		ptr = ptr->rightnode;
	}
	return;
}

void push(nodePointer ptr) {
	top++;
	stack[top] = ptr;
	return;
}

nodePointer pop() {
	nodePointer ptr;
	if (top == -1) 
		return NULL;

	ptr = stack[top];
	top--;
	return ptr;
}

void read_child() {
	nodePointer ptr = find();
	if (ptr == NULL) {
		printf("�ڷᰡ �����ϴ�.\n");
		return;
	}
	printf("����  �ڽ� : ");
	if (ptr->leftnode == NULL)
		printf("����\n");
	else
		printf("<%d , %s, %s>\n", ptr->leftnode->num, ptr->leftnode->employee.name, ptr->leftnode->employee.address);

	printf("������  �ڽ� : ");
	if (ptr->rightnode == NULL)
		printf("����\n");
	else
		printf("<%d , %s, %s>\n", ptr->rightnode->num, ptr->rightnode->employee.name, ptr->rightnode->employee.address);
	return;
}