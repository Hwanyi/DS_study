#pragma once

typedef struct node node, *nodePointer;

typedef struct data data;

void insert();
nodePointer find();
void read();
void push(nodePointer ptr);
nodePointer pop();
void read_child();