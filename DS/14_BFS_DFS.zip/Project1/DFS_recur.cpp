#include <stdio.h>
#include <stdlib.h>

#define FALSE 0
#define TRUE 1

struct node {
	int vertex;
	struct node *link;
};

typedef struct node *nodePointer;
typedef struct node node;

int visited[100];
node *adjLists[100];
int Queue[100];
int front;
int rear;

int Stack[100];
int top = -1;


void initialize_visited() {
	for (int i = 0; i < 100; i++)
		visited[i] = FALSE;
	return;
}

void initialize_adj() {
	for (int i = 0; i < 100; i++) {
		adjLists[i] = (nodePointer)malloc(sizeof(node));
		adjLists[i]->vertex = -1;
		adjLists[i]->link = NULL;
	}
	return;
}

void add_List(int vertex1, int vertex2) {
	nodePointer cur = adjLists[vertex1];
	cur->vertex = vertex1;

	nodePointer input_node;
	input_node = (nodePointer)malloc(sizeof(node));
	input_node->vertex = vertex2;
	input_node->link = NULL;

	while (1) {
		if (cur->link == NULL) {
			cur->link = input_node;
			break;
		}
		cur = cur->link;
	}

	cur = adjLists[vertex2];
	cur->vertex = vertex2;

	input_node = (nodePointer)malloc(sizeof(node));
	input_node->vertex = vertex1;
	input_node->link = NULL;

	while (1) {
		if (cur->link == NULL) {
			cur->link = input_node;
			break;
		}
		cur = cur->link;
	}
	return;
}

void dfs_re(int v) {
	nodePointer search = adjLists[v]->link;
	visited[v] = TRUE;
	printf("%d, ", v);
	while (1) {
		if (search == NULL)
			break;
		if (visited[search->vertex] == FALSE)
			dfs_re(search->vertex);
		search = search->link;
	}
}

void add_Queue(int v) {
	Queue[rear] = v;
	rear++;
	return;
}

int delete_Queue() {
	if (front == rear)
		return -1;
	int v = Queue[front];
	front++;
	return v;
}

void bfs_it(int v) {
	front = 0;
	rear = 0;
	nodePointer search;

	printf("%d, ", v);
	visited[v] = TRUE;
	add_Queue(v);

	while (1) {
		v = delete_Queue();

		if (v == -1)
			return;

		search = adjLists[v]->link;
		while (1) {
			if (search == NULL)
				break;
			if (visited[search->vertex] == FALSE) {
				printf("%d, ", search->vertex);
				visited[search->vertex] = TRUE;
				add_Queue(search->vertex);
			}

			search = search->link;
		}
	}
}

void bfs_re(int v) {
	nodePointer search = adjLists[v]->link;
	int temp = v;
	if(visited[v] == FALSE) {
		printf("%d, ", v);
		visited[v] = TRUE;
	}

	while (1) {
		if (search == NULL)
			break;
		if (visited[search->vertex] == FALSE) {
			printf("%d, ", search->vertex);
			visited[search->vertex] = TRUE;
		}
		search = search->link;
	}
	if(adjLists[v+1]->vertex != -1)
		bfs_re(v + 1);
	return;
}

void push_stack(int v) {
	visited[v] = TRUE;
	printf("%d, ", v);
	top++;
	if (top >= 100) {
		printf("stack is full!\n");
		exit(1);
	}
	Stack[top] = v;
	return;
}

int pop_stack() {
	if (top == -1)
		return -1;
	int v = Stack[top];
	return v;
}

void dfs_it(int v) {
	int num;
	nodePointer search;

	push_stack(v);
	
	while (1) {
		int found = 1;
		num = pop_stack();
		if (num == -1)
			break;
		
		search = adjLists[num]->link;

		while (1) {
			if (search == NULL) {
				found = 0;
				break;
			}
			if (visited[search->vertex] == FALSE)
				break;
			search = search->link;
		}
		if (found == 1)
			push_stack(search->vertex);
		else
			top--;
	}

	return;
}

int main() {
	int vertex1 = 0;
	int vertex2 = 0;
	int edge_num = 0;

	initialize_adj();
	initialize_visited();
	printf("Graph�� �Է��ϼ���.\n");
	printf("(edge ��ȣ vertex ��ȣ vertex ��ȣ) -1 -1 -1�� �Է����� .\n");
	while (1) {
		scanf("%d %d %d", &edge_num, &vertex1, &vertex2);
		if (edge_num == -1)
			break;
		add_List(vertex1, vertex2);

	}

	int x = 0;
	printf("��� ���� : Vertex(Adjacent vertex list)\n");
	while (1) {
		if (adjLists[x]->vertex == -1)
			break;
		nodePointer cur = adjLists[x]->link;
		printf("%d (", x);
		while (1) {
			if (cur == NULL)
				break;

			printf("%d, ", cur->vertex);
			cur = cur->link;
		}
		printf("\b\b)\n");
		x++;
	}

	int num;
	printf("Starting vertex�� number�� �Է��Ͻÿ� : ");
	scanf("%d", &num);

	printf("DFS(recursive version)�� ��� : ");
	dfs_re(num);
	printf("\n");

	initialize_visited();
	printf("DFS(iterative version)�� ��� : ");
	dfs_it(num);
	printf("\n");

	initialize_visited();
	printf("BFS(iterative version)�� ��� : ");
	bfs_it(num);
	printf("\n");

	initialize_visited();
	printf("BFS(recursive version)�� ��� : ");
	bfs_re(num);
	printf("\n");

	return 0;
}