#include <stdio.h>
#include <time.h>
#include <stdlib.h>

inline void swap(int* x, int* y) {
	int z;
	z = *x;
	*x = *y;
	*y = z;
}

void selection_sort(int a[], int n) {
	int temp = 0;
	int min;
	for (int i = 0; i < n - 1; i++)
	{
		min = i;
		for (int j = i; j < n; j++)
		{
			if (a[min] > a[j])
				min = j;
		}
		if (min != i) {
			swap(&a[min], &a[i]);
		}
	}
	return;
}
void insertion_sort(int a[], int n) {
	int j;
	int temp;
	for (int i = 1; i < n; i++)
	{
		j = i;
		temp = a[i];
		while (1) {
			if (temp > a[j - 1])
				break;
			a[j] = a[j - 1];
			j--;
			if (j == 0)
				break;
		}
		a[j] = temp;

	}
	return;
}


void quick_sort(int a[], int left, int right) {
	int pivot, i, j;
	int temp;
	if (left < right) {
		i = left; j = right + 1;
		pivot = a[left];
		do {
			do { i++; } while (a[i] < pivot);
			do { j--; } while (pivot < a[j]);
			if (i < j) swap(&a[i], &a[j]);
		} while (i < j);
		swap(&a[left], &a[j]);
		quick_sort(a, left, j - 1);
		quick_sort(a, j + 1, right);
	}
}

void quick_sort_median(int a[], int left, int right) {
	int pivot, i, j;
	int median;
	int temp;
	if (left < right) {
		i = left; j = right + 1; median = (left + right) / 2;
		if (a[median] < a[right]) {
			if (a[left] < a[median])
				swap(a + left, a + median);
			else if (a[right] < a[left])
				swap(a + left, a + right);
		}
		pivot = a[left];
		do {
			do { i++; } while (a[i] < pivot);
			do { j--; } while (pivot < a[j]);
			if (i < j) swap(&a[i], &a[j]);
		} while (i < j);
		swap(&a[left], &a[j]);
		quick_sort_median(a, left, j - 1);
		quick_sort_median(a, j + 1, right);
	}
}
int main() {

	//int a[10] = { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
	int a[100000];
	clock_t start_t;
	clock_t end_t;

	for (int i = 0; i < 100000; i++)
		a[i] = rand();

	start_t = clock();

	//selection_sort(a, 3400);
	//insertion_sort(a, 3400);
	quick_sort(a, 0, 100000 - 1);
	//quick_sort_median(a, 0, 1000000 - 1);

	end_t = clock();
	printf("�ɸ��� �ð� : %d\n", end_t - start_t);

	/*for (int i = 0; i < 100; i++)
	{
		printf("%d ", a[i]);
	}*/
	return 0;
}