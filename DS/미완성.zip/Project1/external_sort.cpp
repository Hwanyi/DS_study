#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int w_tree[8];

struct run_data {
	int run[1024];
	int index;
};

void selection_sort(int arr[], int n) {
	int min;
	int temp;
	for (int i = 0; i < n; i++)
	{
		min = i;
		for (int j = i; j < n; j++)
		{
			if (arr[j] < arr[min])
				min = j;
		}

		if (min != i) {
			temp = arr[i];
			arr[i] = arr[min];
			arr[min] = temp;
		}
	}


}

int main() {
	srand((unsigned)time(NULL));

	FILE *origin = fopen("origin.dat", "wb+");
	FILE *temp1 = fopen("temp1.dat", "wb+");
	FILE *temp2 = fopen("temp2.dat", "wb+");

	int a;

	int key[10240];
	for (int i = 0; i < 10240; i++)
	{
		key[i] = -1;
	}


	if (origin == NULL) {
		printf("������ ã�� ���߽��ϴ�.\n");
		exit(1);
	}
	
	for (int i = 0; i < 2000000; i++)
	{
		a = rand();
		fwrite(&a, 4, 1, origin);
	}

	rewind(origin);

	int trial = 0;
	
	for (int i = 0; i < 200; i++)
	{
		fread(key, 4, 10000, origin);
		selection_sort(key, 10000);
		fwrite(key, 4, 10240, temp1);
		if (trial % 15 == 0) {
			system("cls");
			printf("Sort Phase.");
		}
		printf(".");
		trial++;
	}
	system("cls"); 
	printf("Sorting end\n");
	fclose(origin); //origin.dat �� ���� �� ���δ� �̸� ��Ʈ���� �ݾ�����
	/***********************************************///Sort_Phase_end
	
	rewind(temp1);	//temp1�� ������ run�� ������ߵȴ� ���� 
	FILE* f_run[4];
	run_data running[4];

	//�����ϸ� �ݺ������� �Ʒ� �ּ�����//

	for (int j = 0; j < 50; j++)
	{
		for (int i = 0; i < 8; i++)
			w_tree[i] = 0;				//Winner_tree �ʱ�ȭ

		for (int i = 0; i < 4; i++)
		{
			f_run[i] = temp1;
			fread(running[i].run, 4, 1024, f_run[i]);
			running[i].index = 0;
			fseek(temp1, 10240 * sizeof(int), SEEK_CUR);
		}

		/*4-way-merge-sort implement*/
		{
			w_tree[4] = 0;
			w_tree[5] = 1;
			w_tree[6] = 2;
			w_tree[7] = 3;

			if (running[w_tree[4]].run[0] < running[w_tree[5]].run[0])
				w_tree[2] = w_tree[4];
			else
				w_tree[2] = w_tree[5];

			if (running[w_tree[6]].run[0] < running[w_tree[7]].run[0])
				w_tree[3] = w_tree[6];
			else
				w_tree[3] = w_tree[7];

			if (running[w_tree[2]].run[0] < running[w_tree[3]].run[0])
				w_tree[1] = w_tree[2];
			else
				w_tree[1] = w_tree[3];
		}//w_tree_initialize

		while (1) {
			if (w_tree[1] == -1)
				break;

			int number = w_tree[1];
			int child = w_tree[1] + 4;
			int parents = child / 2;

			fwrite(&running[number].run[running[number].index++], 4, 1, temp2);

			if (running[number].index == 1024) {
				/*���ο� ���� ����ֱ�*/
				fread(running[number].run, 4, 1024, f_run[number]);
				running[number].index = 0;
			}
			/*adjust Winner_Tree*/

		}

	}
	//1�� merge sort

	rewind(temp1);
	rewind(temp2);

	/*2�� merge-sort*/

	//������� //�����ϸ� �ݺ������� ����

	/*���*/
	fclose(temp1);
	fclose(temp2);
	return 0;
}